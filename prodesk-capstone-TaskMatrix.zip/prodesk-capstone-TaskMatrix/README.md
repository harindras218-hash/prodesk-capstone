# TaskMatrix — Agile Project Management Platform

**Designated Track:** Full-Stack (MERN)  
**Tech Stack:** React + Vite, Zustand (global state), Tailwind CSS, Node.js, Express, MongoDB (Mongoose), JWT auth  
**Figma Wireframes:** _paste public Figma link here_

## Overview
TaskMatrix lets agile teams plan sprints, manage a Kanban board, and track progress in one workspace.

## Core Features (Prioritized)
### P0 — Base MVP
- Auth: register / login (JWT), protected routes
- Projects: create, list, edit, delete
- Kanban board: Backlog → In Progress → Review → Done (drag & drop)
- Tasks: title, description, assignee, priority, due date

### P1
- Sprint planning (create sprint, add tasks from backlog)
- Comments on tasks
- Role-based access (Admin / Member)

### P2 (Stretch)
- Sprint burndown chart
- Activity log / notifications
- Real-time board sync (Socket.io)

## Architecture Diagrams
- ERD (MongoDB collections): [docs/erd.md](docs/erd.md)
- Zustand state tree: [docs/state-tree.md](docs/state-tree.md)
- Mock API endpoints: [docs/mock-api.md](docs/mock-api.md)

> After exporting from Draw.io, embed images here:
> `![ERD](docs/erd.png)` and `![State Tree](docs/state-tree.png)`

## Run the docs viewer locally
```bash
npm start
```
Opens the diagrams at http://localhost:3000
