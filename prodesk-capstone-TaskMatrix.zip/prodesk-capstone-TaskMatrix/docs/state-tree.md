# Zustand State Tree

```mermaid
flowchart TD
  S[Root Store] --> A[authSlice]
  S --> P[projectSlice]
  S --> T[taskSlice]
  S --> SP[sprintSlice]
  S --> U[uiSlice]
  A --> A1["user, token, isAuthenticated"]
  A --> A2["login(), register(), logout()"]
  P --> P1["projects[], activeProjectId"]
  P --> P2["fetchProjects(), createProject()"]
  T --> T1["tasksByProject{}, columns{}"]
  T --> T2["fetchTasks(), moveTask(), createTask()"]
  SP --> SP1["sprints[], activeSprint"]
  U --> U1["modalOpen, theme, loading, error"]
```
