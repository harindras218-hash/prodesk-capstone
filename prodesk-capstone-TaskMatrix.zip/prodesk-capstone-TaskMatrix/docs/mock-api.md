# Mock API Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | /api/auth/register | Create account |
| POST | /api/auth/login | Login, returns JWT |
| GET | /api/projects | List user projects |
| POST | /api/projects | Create project |
| GET | /api/projects/:id | Project details |
| PUT | /api/projects/:id | Update project |
| DELETE | /api/projects/:id | Delete project |
| GET | /api/projects/:id/tasks | Tasks of a project |
| POST | /api/tasks | Create task |
| PATCH | /api/tasks/:id | Update task / move column |
| DELETE | /api/tasks/:id | Delete task |
| GET | /api/projects/:id/sprints | List sprints |
| POST | /api/sprints | Create sprint |
| POST | /api/tasks/:id/comments | Add comment |
