# ERD — MongoDB Collections

```mermaid
erDiagram
  USER ||--o{ PROJECT : owns
  USER }o--o{ PROJECT : "member of"
  PROJECT ||--o{ SPRINT : has
  PROJECT ||--o{ TASK : contains
  SPRINT ||--o{ TASK : includes
  USER ||--o{ TASK : "assigned to"
  TASK ||--o{ COMMENT : has
  USER ||--o{ COMMENT : writes

  USER { ObjectId _id string name string email string passwordHash string role }
  PROJECT { ObjectId _id string name string description ObjectId owner ObjectId[] members }
  SPRINT { ObjectId _id ObjectId project string name date startDate date endDate string status }
  TASK { ObjectId _id ObjectId project ObjectId sprint string title string description string status string priority ObjectId assignee date dueDate }
  COMMENT { ObjectId _id ObjectId task ObjectId author string body date createdAt }
```
